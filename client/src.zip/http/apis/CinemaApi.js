import myaxios from "../MyAxios"
import baseurl from '../BaseUrl'
const BMDURL=baseurl.BMDURL


const cinemaapi={

  queryAllTags(){
    let url=BMDURL+'/cinema/tags'
    return myaxios.get(url)
  },
  add(params){
    let url=BMDURL+'/cinema/add'
    return myaxios.post(url,params)
  },
  query(){
    let url=BMDURL+'/cinemas'
    return myaxios.get(url)
  }
}
export default cinemaapi