<template>
  <div id="app">
    <!-- 一级路由占位符 -->
    <router-view/>
  </div>
</template>

<style lang="scss">
*{
  margin: 0;
  padding: 0;
}
</style>
