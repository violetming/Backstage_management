<template>
  <div>
    添加导演
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss" scoped>

</style>